
def generate_questions(skills, projects):
    questions = []
    
    for skill in skills:
        questions.append(f"Can you explain your experience with {skill}?")
        questions.append(f"What challenges have you faced while working with {skill}?")

    for project in projects:
        questions.append(f"Can you walk me through your project: {project}?")
        questions.append(f"What role did you play in the development of {project}?")
    
    return questions

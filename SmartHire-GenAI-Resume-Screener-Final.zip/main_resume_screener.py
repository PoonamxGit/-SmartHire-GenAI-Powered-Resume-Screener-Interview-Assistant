
from interview_questions import generate_questions

# Sample resumes
sample_resumes = [
    {
        "name": "Tanupriya Singh",
        "skills": ["Java", "Spring Boot", "REST APIs"],
        "projects": ["Online Book Store", "Resume Ranking System"]
    },
    {
        "name": "Poonam Verma",
        "skills": ["C++", "React", "MongoDB"],
        "projects": ["University Timetable Scheduler", "Personal Portfolio Website"]
    },
    {
        "name": "Apoorv Sharma",
        "skills": ["Python", "Machine Learning", "Flask"],
        "projects": ["Sales Forecasting using Time Series Analysis", "Resume Screener using GenAI"]
    }
]

# === Resume Screening Feature ===
job_description = {
    "required_skills": {"Python", "Machine Learning", "SQL", "Flask"}
}

def screen_resume(resume):
    candidate_skills = set(resume["skills"])
    matched_skills = candidate_skills.intersection(job_description["required_skills"])
    match_score = len(matched_skills) / len(job_description["required_skills"]) * 100
    return match_score, matched_skills

# Run screening and question generation
for resume in sample_resumes:
    print(f"\n===== Candidate: {resume['name']} =====")
    
    # Screening
    score, matched = screen_resume(resume)
    print(f"Resume Match Score: {score:.2f}%")
    print(f"Matched Skills: {', '.join(matched) if matched else 'None'}")
    
    # Interview Questions
    print("Interview Questions:")
    questions = generate_questions(resume["skills"], resume["projects"])
    for q in questions:
        print("-", q)

# SmartHire: GenAI-Powered Resume Screener & Interview Assistant

This project automatically analyzes resumes using AI and matches them to job descriptions. It also generates interview questions.

## Features
- Resume matching using NLP (TF-IDF + cosine similarity)
- Easy to use and extensible

## Folder Structure

```
SmartHire/
├── main_resume_screener.py
├── resumes/
├── requirements.txt
└── README.md
```

## How to Run

1. Install required packages:
   ```
   pip install -r requirements.txt
   ```

2. Add resumes in the `resumes/` folder

3. Run:
   ```
   python main_resume_screener.py
   ```

## Sample Output

See `sample_output.txt`


## 📌 New Features Added

### 1. Resume Screening
Automatically scores each candidate against a job description based on required skills.

**Example Output:**
- Resume Match Score: 75.00%
- Matched Skills: Python, Flask, Machine Learning

### 2. Interview Question Generator
Generates personalized interview questions from the candidate's skills and project experiences.

**Example Questions:**
- Can you explain your experience with Flask?
- What role did you play in the development of Resume Screener using GenAI?

Run `main_resume_screener.py` to test both features.
